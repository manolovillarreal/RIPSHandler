import {
  printFileList,
  renderDataContainer,
  showValidationOptions,
  setErrorAlert,
} from "./UIManager.js";
import { RIPS } from "./ripsManager.js";
import { onFileInputChange, onDropFiles, loadRipsData } from "./fileHandler.js";
import { getCUPSRipsTable } from "./Api/RefsTables.js";
//#region  Get DOM Elements

const inputFileRIPS = document.getElementById("inputFileRIPS");
const fileListDOM = document.getElementById("fileList");
const dropZone = document.getElementById("drop_zone");
const toggleButtons = document.getElementsByClassName("btnToggleView");
console.log(toggleButtons);

//#endregion

let ripsFiles = [];
let ripsData = {};
let errors = [];
initDOMEvents();

function initDOMEvents() {
  inputFileRIPS.onchange = fileInputChangeHandler;

  dropZone.ondrop = dropHandler;
  dropZone.ondragover = dragOverHandler;

  for (const btn of toggleButtons) {
    btn.onclick = toggleClickHanlder;
  }
  document.querySelector("#btnloadFiles").onclick = loadFilesHandler;
  document.querySelector("#validate_Btn").onclick = validarRips;
}

function fileInputChangeHandler() {
  const files = onFileInputChange(this);
  setRipsFiles(files);
}
function dropHandler(ev) {
  ev.preventDefault();
  const files = onDropFiles(ev);
  setRipsFiles(files);
  setShowBtnLoadFiles(true);
  onRemoveDragData(ev);
}

function dragOverHandler(ev) {
  console.log("File(s) in drop zone");
  ev.preventDefault();
}
function loadFilesHandler() {
  ripsData = {};
  for (const rips of ripsFiles) {
    loadRipsData(rips, (err, data) => {
      if (err) {
        console.log(err);
        return;
      }
      console.log("callback");

      ripsData[rips.name] = RIPS.extractFields(rips, data);
      console.log(ripsData);
      if (Object.keys(ripsData).length == ripsFiles.length) {
        renderDataContainer(ripsData);
        setShowBtnLoadFiles(false);
        showValidationOptions();
      }
    });
  }
}

function setShowBtnLoadFiles(show) {
  const btn = document.querySelector("#btnloadFiles");
  if (show) {
    if (btn.classList.contains("hidden")) {
      btn.classList.remove("hidden");
    }
  } else {
    if (!btn.classList.contains("hidden")) {
      btn.classList.add("hidden");
    }
  }
}

function toggleClickHanlder() {
  for (const btn of toggleButtons) {
    if (btn.classList.contains("hidden")) btn.classList.remove("hidden");
    else btn.classList.add("hidden");
  }
}
function onRemoveDragData(ev) {
  if (ev.dataTransfer.items) {
    // Use DataTransferItemList interface to remove the drag data
    ev.dataTransfer.items.clear();
  } else {
    // Use DataTransfer interface to remove the drag data
    ev.dataTransfer.clearData();
  }
}

function setRipsFiles(files) {
  ripsData = {};
  ripsFiles = [];
  for (const file of files) {
    ripsFiles.push({ ...RIPS.characterizeFile(file.name), file });
  }
  ripsFiles = ripsFiles.sort((a, b) =>
    a.name > b.name ? 1 : b.name > a.name ? -1 : 0
  );
  printFileList(fileListDOM, ripsFiles);
}

const removeAccents = (str) => {
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
};

async function validarRips() {
  for (const { fileName, fixes } of pisisSuit) {
    console.log(fileName + ": ");
    if (!ripsData[fileName]) {
      errors.push("No se cargo el archivo " + fileName);
      continue;
    }
    for (const fix of fixes) {
      console.log(fix.name);
      const result = await fix.run(fileName);
    }
  }
  setErrorAlert(errors);
}

const ReemplazarTildes = {
  name: "Reemplaza Tildes",
  run: async (file) => {
    const data = ripsData[file];

    for (const line of data) {
      for (const field in line) {
        line[field] = removeAccents(line[field]);
      }
    }

    return { ok: true, msg: "Se reemplazaron las tildes" };
  },
};

const ElimiarEspacios = {
  name: "Eliminar Espacios",
  run: async (file) => {
    const data = ripsData[file];

    for (const line of data) {
      for (const field in line) {
        line[field] = line[field].trim();
      }
    }
    return { ok: true, msg: "Se Eliminaron los espacios" };
  },
};

const NormalizarCUMS = {
  name: "Normalizar CUMS",
  run: async (file) => {
    const data = ripsData[file];
    let cont = 0;
    for (const line of data) {
      let rawCUM = line["Codigo"];
      let CUM = CUM.split("-");
      if (CUM.length === 2) {
        CUM[0] = Number(CUM[0]);
        CUM[1] = Number(CUM[1]);

        line["Codigo"] = CUM[0] + "-" + CUM[1];

        if (line["Codigo"] !== rawCUM) {
          cont++;
        }
      }
    }
    return { ok: true, msg: `Se normalizaron ${cont} CUM` };
  },
};

// const ValidarCampos = {
//   name: "Verificar Campos",
//   params: [...RIPS.RequiredFields],
//   run(fileName) {
//     return VerificarCampos(fileName, params);
//   },
// };

const CruzarCUPS = {
  name: "CUPS RIPS",
  field: "codido",
  run: async (file) => {
    const CUPSRips = await getCUPSRipsTable();
    const SOAT_CUPS = await getSOAT_CUPS();
    const data = ripsData[file];
    const resp = { details: [], errors: [] };
    for (let i = 0; i < data.length; i++) {
      const ripsLine = data[i];

      const codigo = ripsLine.Codigo;
      if (!CUPSRips.some((cup) => cup.Codigo == codigo)) {
        const reemplazo = SOAT_CUPS[codigo];
        if (reemplazo) {
          ripsLine.Codigo = reemplazo;
          resp.details.push({
            msg: `se reemplazo el codigo ${codigo} por ${reemplazo}`,
          });
        } else {
          resp.errors.push({
            error: true,
            msg: `se reemplazo el codigo ${codigo} por ${reemplazo}`,
            line: i + 1,
          });
        }
      }
    }
  },
};

const VerificarCampos = (file, fields) => {
  const data = ripsData[file];
  const errors = [];
  for (let i = 0; i < data.length; i++) {
    const line = data[i];
    for (const field of fields) {
      !line[field] || line[field] == "";
      errors.push({ line: i, msg: `El campo ${field} es requerido`, field });
    }
  }
  return errors;
};

const pisisSuit = [
  {
    fileName: "CT",
    fixes: [],
    tests: [],
  },
  {
    fileName: "AC",
    fixes: [],
    tests: [],
  },
  {
    fileName: "AF",
    fixes: [],
    tests: [],
  },
  {
    fileName: "AM",
    fixes: [ReemplazarTildes, ElimiarEspacios, NormalizarCUMS],
    tests: [],
  },
  {
    fileName: "AP",
    fixes: [],
    tests: [],
  },
  {
    fileName: "AT",
    fixes: [ReemplazarTildes, ElimiarEspacios],
    tests: [],
  },
  {
    fileName: "US",
    fixes: [ReemplazarTildes, ElimiarEspacios],
    tests: [],
  },
];
