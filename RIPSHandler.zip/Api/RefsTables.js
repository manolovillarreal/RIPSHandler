export function getCUPSRipsTable() {
  fetch("../data/CUPSRIPS.json")
    .then((response) => response.json())
    .then((obj) => console.log(obj));
}

export function getSOAT_CUPS() {
  fetch("../data/SOAT_CUPS.json")
    .then((response) => response.json())
    .then((obj) => console.log(obj));
}
