export function printFileList(fileListDOM, ripsFiles) {
  fileListDOM.innerHTML = "";
  for (const { name, code, desc } of ripsFiles) {
    fileListDOM.innerHTML += `
                       <div id="${name}" class="fileRow">                    
                           ${code} - ${desc} 
                           <div class="btn-div"> 
                               <ion-icon name="close-circle-outline"  size="large"></ion-icon>
                           </div>  
                           <div class="btn-div"> 
                               <ion-icon name="reload-circle-outline" size="large"></ion-icon>  
                           </div>  
                       </div>`;
  }
  fileListDOM.parentNode.style.display = "block";
}

export function renderDataContainer(ripsData) {
  for (const fileName in ripsData) {
    const rips = ripsData[fileName];

    document.querySelector("#ripsDataContainer").style.display = "block";
    document.querySelector("#nav-tab").prepend(genNavTab(fileName));
    document.querySelector("#nav-tabContent").innerHTML += genTabPanel(
      fileName,
      rips
    );
    // printOutput(rips, fileName);
    checkForErrors(fileName, rips);
    // checkForErrors(rips.name,rips.code)
  }
}

export function showValidationOptions() {
  document.querySelector("#validationContainer").classList.remove("hidden");
}

function printOutput(rips, name) {
  const output = document.getElementById("nav-" + name);
  output.innerHTML = "";
  let outputLine = "";
  for (let i = 0; i < rips.length; i++) {
    let ripsLine = rips[i];
    let str = i + 1 + ")";
    for (const field in ripsLine) {
      str += ripsLine[field] + ",";
    }

    const className = ripsLine.error ? "error" : "data";
    const data = ripsLine.error ? ripsLine.line + ")" + ripsLine.msg : str;
    outputLine += `<div class="${className}">  ${data}  </div>`;
  }
  output.innerHTML += outputLine;
}

function checkForErrors(name, rips) {
  const _errors = rips.filter((i) => i.error);

  if (_errors.length > 0) {
    document.getElementById(name).style.color = "red";
    for (const error of _errors) {
    }
  }
}

function genNavTab(name) {
  const btn = document.createElement("button");
  btn.className = "nav-link";
  btn.id = `nav-${name}-tab`;
  btn.type = "button";
  btn.setAttribute("role", "tab");
  btn.setAttribute("data-bs-toggle", "tab");
  btn.setAttribute("data-bs-target", `#nav-${name}`);
  btn.setAttribute("aria-controls", `nav-${name}`);
  btn.setAttribute("aria-selected", true);
  btn.innerText = name;
  return btn;
}
function genTabPanel(name, rips) {
  return `<div 
            class="tab-pane fade" 
            id="nav-${name}" 
            role="tabpanel" 
            aria-labelledby="nav-${name}-tab"
          >
          </div>`;
}

export function setErrorAlert(errors) {
  const errorAlert = document.querySelector("#errorAlert");
  if (errors.length > 0) {
    errorAlert.innerHTML = "";
    for (const err of errors) {
      errorAlert.innerHTML += `<div> ${err}</div>`;
    }

    errorAlert.style.display = "block";
  } else {
    errorAlert.style.display = "none";
  }
}
